drop table notes;
drop table choix;
drop table module;
drop table etudiant;
drop table master_;
drop table choix_disp;

create table ETUDIANT(
    rang NUMBER,
    code_e number,
    nom varchar(20),
    prenom varchar(20),
    moyenne float(7),
    specialite varchar(20),
    constraint key_constraint_e primary key (code_e));

create table module(
code_m varchar(20),
intitule varchar(40),
coefficient number, 
constraint key_constraint_m primary key(code_m));



create table NOTES(
code_e number,
code_m varchar(20),
note number,
CONSTRAINT fkey_constraint_n_e FOREIGN KEY(code_e) REFERENCES ETUDIANT(code_e),
CONSTRAINT fkey_constraint_n_m FOREIGN KEY(code_m) REFERENCES MODULE(code_m),
CONSTRAINT composite_key_n primary key (code_e,code_m));

insert into Etudiant (code_e,nom,prenom) values (10000,'N1','P1');
insert into Etudiant (code_e,nom,prenom) values (20000,'N2','P2');
insert into Etudiant (code_e,nom,prenom) values (30000,'N3','P3');
insert into Etudiant (code_e,nom,prenom) values (40000,'N4','P4');
insert into Etudiant (code_e,nom,prenom) values (50000,'N5','P5');
insert into Etudiant (code_e,nom,prenom) values (60000,'N6','P6');

insert into MODULE (code_m,intitule,coefficient) values ('BDA','base de donnees avance',2);
insert into MODULE (code_m,intitule,coefficient) values ('PWA','programmation web avancee',2);
insert into MODULE (code_m,intitule,coefficient) values ('MS','modelisation est simulation',3);

insert into notes values (10000,'BDA',20);
insert into notes values (10000,'PWA',20);
insert into notes values (10000,'MS', 20);
insert into notes values (20000,'BDA',10);
insert into notes values (20000,'PWA',10);
insert into notes values (20000,'MS', 6 );
insert into notes values (30000,'BDA',4 );
insert into notes values (30000,'PWA',4 );
insert into notes values (30000,'MS', 0 );
insert into notes values (40000,'BDA',20);
insert into notes values (40000,'PWA',20);
insert into notes values (40000,'MS', 20);
insert into notes values (50000,'BDA',0 );
insert into notes values (50000,'PWA',0 );
insert into notes values (50000,'MS', 0 );
insert into notes values (60000,'BDA',1 );
insert into notes values (60000,'PWA',2 );
insert into notes values (60000,'MS', 3 );


create or replace procedure moy_rang is
   c_code_e ETUDIANT.code_e%type;
   c_moy float(7);
   last_moy float(7):=null;
   n number:=1;
   
   CURSOR cur is
      SELECT code_e ,sum(note*coefficient)/sum(coefficient) as moy
      FROM notes, module 
      where module.code_m=notes.code_m
      group by notes.code_e,code_e 
      order by moy desc ;
BEGIN
   OPEN cur;
   LOOP 
        FETCH cur into c_code_e ,c_moy; EXIT WHEN cur%notfound;
        --setting the average in the table
        update etudiant set moyenne = c_moy where code_e=c_code_e;
        -- increment if the average is different then the last one
        if(last_moy!=c_moy) then
            n:=n+1;
        end if;
        -- set the rang
        update etudiant set rang=n where code_e=c_code_e;
        last_moy:=c_moy;
   END LOOP;
   CLOSE cur;

END;
/


begin
moy_rang();
end;
/

CREATE OR REPLACE TRIGGER range_valid
    BEFORE INSERT OR UPDATE OF note
    ON notes
    FOR EACH ROW
    
BEGIN
    IF(:new.note < 0 OR :new.note > 20) THEN
        raise_application_error(-20000,' notes have to be between 0 and 20');
    END IF;
END;

/

update notes set note=10 where code_e=40000;
-- recalculating the rang and the moyenne
begin
    moy_rang();
end;
/

create table Master_(
    rang NUMBER,
    code_e number primary key,
    nom varchar(20),
    prenom varchar(20),
    moyenne float(7),
    specialite varchar(20));

create table choix(
    code_e number ,
    choix1 varchar(20),
    choix2 varchar(20),
    choix3 varchar(20),
    constraint fkey_constraint_c_e 
        FOREIGN KEY (code_e) 
        REFERENCES ETUDIANT(code_e),      
    constraint composite_key_c 
        primary key (code_e,choix1,choix2,choix3));

insert into choix values(10000,'RSD','IDTW','IFIA');
insert into choix values(20000,'RSD','IDTW','IFIA');
insert into choix values(30000,'RSD','IDTW','IFIA');
insert into choix values(40000,'RSD','IDTW','IFIA');
insert into choix values(50000,'RSD','IDTW','IFIA');
insert into choix values(60000,'RSD','IDTW','IFIA');

create table choix_disp(
choix varchar(20),
disp number,
lim number,
constraint key_constraint primary key (choix));
 
insert into choix_disp values('RSD' ,2,2);
insert into choix_disp values('IDTW',2,2);
insert into choix_disp values('IFIA',2,2);

CREATE OR REPLACE PROCEDURE asign_speciality
IS
   c_code_e ETUDIANT.code_e%TYPE;
   c_choix1 choix.choix1%TYPE;
   c_choix2 choix.choix2%TYPE;
   c_choix3 choix.choix3%TYPE;
   choix0 choix.choix1%TYPE;
   c_moy FLOAT(7);
   n NUMBER;
   
   TYPE disp_tab_t IS TABLE OF NUMBER INDEX BY choix_disp.choix%TYPE;
   disp_tab disp_tab_t;
   
   CURSOR c_choix_disp IS SELECT choix_disp.choix,disp FROM choix_disp;
   
   CURSOR c_choix is SELECT choix.code_e,choix1,choix2,choix3 
            FROM choix  JOIN etudiant ON choix.code_e=etudiant.code_e 
            ORDER BY rang ASC;
BEGIN
    
    OPEN c_choix_disp;
    LOOP FETCH c_choix_disp INTO choix0,n;  
        EXIT WHEN c_choix_disp%notfound;
        disp_tab(choix0):=n;

    END LOOP;
    CLOSE c_choix_disp;
    
    OPEN c_choix;
    LOOP FETCH c_choix INTO c_code_e,c_choix1,c_choix2,c_choix3;
    EXIT WHEN c_choix%notfound;
            -- if the first choixe is available assign it to the student
           
            IF disp_tab(c_choix1)>0 THEN
                choix0:=c_choix1;
            ELSIF  disp_tab(c_choix2)>0 THEN 
                choix0:=c_choix2;
            ELSIF  disp_tab(c_choix3)>0 THEN 
                choix0:=c_choix3; 
            ELSE choix0:='no spaces left';
            END IF;
            
            disp_tab(choix0):=disp_tab(choix0)-1 ;
            
            INSERT INTO master_ 
            SELECT rang,code_e,nom,prenom,moyenne, choix0
            FROM etudiant WHERE code_e=c_code_e;
    END LOOP;
    CLOSE c_choix;
   
    OPEN c_choix_disp;
    LOOP FETCH c_choix_disp INTO choix0,n;
        EXIT WHEN c_choix_disp%notfound;
        update choix_disp SET disp=disp_tab(choix0) 
            WHERE choix_disp.choix=choix0;
    END LOOP;
    CLOSE c_choix_disp;
END;
/

begin 
asign_speciality();
end;
/

-- see results
select * from etudiant order by rang;
select * from master_ order by rang;
select * from choix_disp;

